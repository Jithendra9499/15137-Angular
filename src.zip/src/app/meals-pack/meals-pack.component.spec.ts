import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MealsPackComponent } from './meals-pack.component';

describe('MealsPackComponent', () => {
  let component: MealsPackComponent;
  let fixture: ComponentFixture<MealsPackComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MealsPackComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MealsPackComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
