import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-meals-pack',
  templateUrl: './meals-pack.component.html',
  styleUrls: ['./meals-pack.component.css']
})
export class MealsPackComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
