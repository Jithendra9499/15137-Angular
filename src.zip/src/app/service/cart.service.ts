import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CartService {

  public mycartItemList : any=[]
  public productList = new BehaviorSubject<any>([]);

  constructor() { }
  getProducts(){
    return this.productList.asObservable();
  }
  setProduct(product : any){
    this.mycartItemList.push(...product);
    this.productList.next(product);
  } 
  addtoCart(product : any){
    this.mycartItemList.push(product);
    this.productList.next(this.mycartItemList);
    this.getTotalPrice();
    console.log(this.mycartItemList)
  }
  //getTotalPrice():number{ 
    //let grandTotal=0;
    //this.mycartItemList.map((a:any)=>{
      //grandTotal += a.total;
    //})
    //return grandTotal;

 // }
 getTotalPrice():number{ 

  let grandTotal=0;
  
this.mycartItemList.forEach((a:any)=>{
grandTotal += parseFloat(a.total)
});
return grandTotal;

}
  removeCartItem(product:any){
    this.mycartItemList.map((a:any,index:any)=>{
      if(product._id=== a._id){
        this.mycartItemList.splice(index,1);
      }
    })
    this.productList.next(this.mycartItemList);
  }
  removeAllCart(){
    this.mycartItemList=[]
    this.productList.next(this.mycartItemList);

  }
}
