import { Component, OnInit } from '@angular/core';
import { CartService } from '../service/cart.service';

@Component({
  selector: 'app-sweets',
  templateUrl: './sweets.component.html',
  styleUrls: ['./sweets.component.css']
})
export class SweetsComponent implements OnInit {
  public data:any;
  productList:any;


  constructor(private cartService:CartService) { }
    ngOnInit(): void {
    this.data={
     
      productList:[{
        "_id":"1",
        "index":1,
        "price":"150",
        "picture":"../../assets/sweetsimages/aata_cookies_1.jpg",
        "name":"Aata Cookies",
        "description":"Aata cookies(150g)",

      },
    {
      "_id":"2",
      "index":2,
      "price":"180",
      "picture":"../../assets/sweetsimages/agar_taj_petha_1.jpg",
      "name":"Agra Petha",
      "description":"Agra Petha(250g)",

    },
    {
      "_id":"3",
      "index":3,
      "price":"160",
      "picture":"../../assets/sweetsimages/badam_halwa_4.jpg",
      "name":"Badam Halwa",
      "description":"Badam Halwa(150g)",

    },
  {
    "_id":"4",
    "index":4,
    "price":"140",
    "picture":"../../assets/sweetsimages/badam_katali_1.jpg",
    "name":"Badam Katali",
    "description":"Badam katali (200g)",
  },
  {
    "_id":"5",
      "index":5,
      "price":"170",
      "picture":"../../assets/sweetsimages/cham_cham_3.jpg",
      "name":"Cham Cham",
      "description":"Cham Cham(250g)",

  },
  {
    "_id":"6",
      "index":6,
      "price":"220",
      "picture":"../../assets/sweetsimages/chocolate_chips_cookies.jpg",
      "name":"Chocolate Chips Cookies",
      "description":"Chocolate Chip Cookies(150g)",

  },
  {
    "_id":"7",
      "index":7,
      "price":"230",
      "picture":"../../assets/sweetsimages/dodha_burfee_1.jpg",
      "name":"Dodha Burfee",
      "description":"Dodha Burfee(180g)",

  },
  {
    "_id":"8",
      "index":8,
      "price":"280",
      //"limit":"4",
      //"quantity":"0",
      "picture":"../../assets/sweetsimages/fruit_biscuits_front.jpg",
      "name":"Fruit Biscuits",
      "description":"Fruit Biscuits(50g)",

  }]
   
    }
    
     //this.productList.forEach((a:any) => {
      //Object.assign(a,{quantity:1,total:a.price});
       //});
  }
  /*increase_quantity(prod:any){
    if(prod.limit == prod.quantity){
      return alert("Can't add more")
    }else{
      prod.quantity++
      this.price += prod.price
    }
  }
  decrease_quantity(prod:any){
      if(prod.quantity == 0){
        return alert("can't be in minus")
      }
      prod.quantity--
      this.price -= prod.price
  } */
      addtocart(prod:any){
        Object.assign(prod,{quantity:1,total:prod.price})
      this.cartService.addtoCart(prod);
    }
    
  }






